import React from 'react'

const Sidebar = () => {
    return (
        <>  
        <div className='sidebar_container'>

            <div className='sidebar_header'>
                <h1>Contents</h1> <span><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12C22 17.5228 17.5228 22 12 22ZM12 20C16.4183 20 20 16.4183 20 12C20 7.58172 16.4183 4 12 4C7.58172 4 4 7.58172 4 12C4 16.4183 7.58172 20 12 20ZM12 10.5858L14.8284 7.75736L16.2426 9.17157L13.4142 12L16.2426 14.8284L14.8284 16.2426L12 13.4142L9.17157 16.2426L7.75736 14.8284L10.5858 12L7.75736 9.17157L9.17157 7.75736L12 10.5858Z"></path></svg></span>
            </div>
            <ul>
                <li>Introduction <span>&gt;</span></li>
                <li>1. Introduction to Microservices <span>&gt;</span></li>
                <li>2. Hands on: Creating Microservices with ASP.net Core <span>&gt;</span></li>
                <li>3. Hands on: Synchronous Communicatio between Microservices <span>&gt;</span></li>
                <li>4. Microservices and DevOps <span>&gt;</span></li>
                <li>5. Microservices Containerisation with Docker <span>&gt;</span></li>
                <li>6. Microservices Deployment <span>&gt;</span></li>
                <li>Conclusion <span>&gt;</span></li>
            </ul>
        </div>
        </>
    )
}

export default Sidebar